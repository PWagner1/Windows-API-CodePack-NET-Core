//Copyright (c) Microsoft Corporation.  All rights reserved.

#include "StdAfx.h"
#include "Direct3DException.h"
